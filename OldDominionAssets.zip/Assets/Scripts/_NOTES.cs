﻿using UnityEngine;
using System.Collections;

public class _NOTES : MonoBehaviour {

	// Use this for initialization
    //Maybe make the game scary
    //make the fact that it's not a platformer 
    //start off with a platformer and move into walking simulator

}
